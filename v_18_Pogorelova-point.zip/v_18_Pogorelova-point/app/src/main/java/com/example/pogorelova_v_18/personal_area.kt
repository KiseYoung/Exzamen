package com.example.pogorelova_v_18

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class personal_area : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_personal_area)
    }
    fun onClick(v: View) {
        val intent: Intent
        when (v.id) {
            R.id.btnCall -> {
                intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:+79016714574")
                startActivity(intent)
            }
            R.id.imageView2 -> {
                val intent = Intent(this@personal_area, login::class.java)
                startActivity(intent)
            }
            R.id.imageView3 -> {
                val intent = Intent(this@personal_area, notice::class.java)
                startActivity(intent)
            }
        }
    }
}